<?php
// Disattiva output errori per non rompere il JSON
ini_set('display_errors', 0);
ini_set('log_errors', 1);
ini_set('error_log', __DIR__.'/error.log');
error_reporting(E_ALL);

require 'PHPMailer/src/Exception.php';
require 'PHPMailer/src/PHPMailer.php';
require 'PHPMailer/src/SMTP.php';

header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['success' => false, 'error' => 'method_not_allowed']);
    exit;
}

/* ===== DATI FORM ===== */
$nome     = trim($_POST['name'] ?? '');
$cognome  = trim($_POST['surname'] ?? '');
$email    = trim($_POST['email'] ?? '');
$telefono = $_POST['tel'] ?? '';
$dataNascita = $_POST['birth_date'] ?? '';
$password = $_POST['password'] ?? '';
$consenso = isset($_POST['consenso']) ? 1 : 0;

/* Controllo campi obbligatori */
if (!$nome || !$email || !$password) {
    http_response_code(400);
    echo json_encode(['success' => false, 'error' => 'missing_fields']);
    exit;
}

/* Controllo email valida */
if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
    http_response_code(400);
    echo json_encode(['success' => false, 'error' => 'email_non_valida']);
    exit;
}

/* ===== HASH PASSWORD E COUPON ===== */
$hashedPassword = password_hash($password, PASSWORD_DEFAULT);
$coupon = 'MAMBO-' . strtoupper(bin2hex(random_bytes(4)));

/* ===== CONNESSIONE DB ===== */
$servername = "mysql.hostinger.com"; // oppure mysql.hostinger.com (dipende dal pannello)
$username   = "u119628533_davideadduci";
$password   = "DavideAdduci1?";
$database   = "u119628533_Mambo";

$conn = new mysqli($servername, $username, $password, $database);

if ($conn->connect_error) {
    http_response_code(500);
    echo json_encode(['success' => false, 'error' => 'db_error']);
    exit;
}

/* ===== CONTROLLO EMAIL DUPLICATA ===== */
$checkStmt = $conn->prepare("SELECT id FROM `user` WHERE email = ? LIMIT 1");
$checkStmt->bind_param("s", $email);
$checkStmt->execute();
$checkStmt->store_result();

if ($checkStmt->num_rows > 0) {
    http_response_code(409);
    echo json_encode(['success' => false, 'error' => 'email_exists']);
    $checkStmt->close();
    $conn->close();
    exit;
}

$checkStmt->close();

/* ===== INSERT UTENTE ===== */
$stmt = $conn->prepare("
    INSERT INTO `user` 
    (name, surname, email, password, birth_date, tel, consenso_privacy, coupon_code)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?)
");

$stmt->bind_param(
    "ssssssis",
    $nome,
    $cognome,
    $email,
    $hashedPassword,
    $dataNascita,
    $telefono,
    $consenso,
    $coupon
);

if (!$stmt->execute()) {
    http_response_code(500);
    echo json_encode(['success' => false, 'error' => 'db_insert_error']);
    exit;
}

/* ===== INVIO EMAIL ===== */
$mail = new PHPMailer\PHPMailer\PHPMailer(true);
try {
    $mail->isSMTP();
    $mail->Host = 'smtp.gmail.com';
    $mail->SMTPAuth = true;
    $mail->Username = 'mamboravarino@gmail.com';
    $mail->Password = 'rkma ijlz mlbq suyq'; // App password Gmail
    $mail->SMTPSecure = PHPMailer\PHPMailer\PHPMailer::ENCRYPTION_STARTTLS;
    $mail->Port = 587;

    $mail->setFrom('mamboravarino@gmail.com', 'Mambo Beauty Lab');
    $mail->addAddress($email, $nome);

    $mail->isHTML(true);
    $mail->Subject = 'Il tuo Coupon 50% - Mambo Beauty Lab';
    $mail->Body = "<h2>Ciao $nome!</h2><p>Il tuo coupon esclusivo: <b>$coupon</b></p>";

    $mail->send();
} catch (PHPMailer\PHPMailer\Exception $e) {
    // Se la mail fallisce, l'utente è già registrato
}

/* ===== OK ===== */
echo json_encode(['success' => true]);

$stmt->close();
$conn->close();
?>
