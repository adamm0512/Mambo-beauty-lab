function openModal() {
    const modal = document.getElementById("modal");
    modal.classList.remove("hidden");
    modal.classList.add("flex");
}

function closeModal() {
    const modal = document.getElementById("modal");
    modal.classList.add("hidden");
    modal.classList.remove("flex");

    // reset per riapertura
    document.getElementById("registerForm").classList.remove("hidden");
    document.getElementById("successMessage").classList.add("hidden");
}

function togglePassword(inputId, button) {
    const input = document.getElementById(inputId);
    if (input.type === "password") {
        input.type = "text";
        button.textContent = "🙈";
    } else {
        input.type = "password";
        button.textContent = "👁";
    }
}

document.addEventListener("DOMContentLoaded", () => {
    const form = document.getElementById("registerForm");
    const successMessage = document.getElementById("successMessage");

    if (!form || !successMessage) return;

    form.addEventListener("submit", async (e) => {
        e.preventDefault();

        const formData = new FormData(form);

        try {
            const response = await fetch("/register_php/register.php", {
                method: "POST",
                body: formData
            });

            // Prova a leggere il testo grezzo in caso di errori PHP
            const text = await response.text();
            let result;
            try {
                result = JSON.parse(text);
            } catch {
                console.error("Response non valida:", text);
                alert("Errore lato server. Controlla log PHP.");
                return;
            }

            if (result.success) {
                form.classList.add("hidden");
                successMessage.classList.remove("hidden");
            } else {
                switch(result.error) {
                    case "email_exists":
                        alert("Questa email e' gia' registrata.");
                        break;
                    case "email_non_valida":
                        alert("Email non valida.");
                        break;
                    case "missing_fields":
                        alert("Compila tutti i campi obbligatori.");
                        break;
                    default:
                        alert("Registrazione fallita. Riprova.");
                }
            }

        } catch (err) {
            console.error(err);
            alert("Errore di connessione. Riprova più tardi.");
        }
    });
});