<?php
session_start();
require_once "config.php";

// Controllo sessione admin
if (!isset($_SESSION['admin_id'])) {
    header('Location: login.php');
    exit;
}

// Prendi i dati dal POST
$id = intval($_POST['id']);
$set_used = intval($_POST['set_used']); // 1 = usato, 0 = non usato

// Aggiorna il coupon
$stmt = $conn->prepare("UPDATE user SET coupon_used = ? WHERE id = ?");
$stmt->bind_param("ii", $set_used, $id);
$stmt->execute();
$stmt->close();

// Torna alla dashboard
header('Location: dashboard.php');
exit;
?>
