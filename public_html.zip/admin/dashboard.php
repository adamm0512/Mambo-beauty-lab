<?php
session_start();

// Controllo sessione admin
if (!isset($_SESSION['admin_id'])) {
    header('Location: login.php');
    exit;
}

require_once "config.php";

// Query utenti
$result = $conn->query("SELECT id, name, surname, email, coupon_code, coupon_used FROM user ORDER BY id DESC");
?>

<!DOCTYPE html>
<html lang="it">
<head>
    <meta charset="UTF-8">
    <title>Dashboard Admin | Mambo Beauty Lab</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-black text-white min-h-screen p-8">

    <h1 class="text-3xl font-bold mb-6 text-yellow-500">Utenti Registrati</h1>

    <table class="w-full border-collapse border border-neutral-700 mb-6">
        <tr class="bg-neutral-900">
            <th class="border border-neutral-700 p-2">Nome</th>
            <th class="border border-neutral-700 p-2">Email</th>
            <th class="border border-neutral-700 p-2">Coupon</th>
            <th class="border border-neutral-700 p-2">Stato</th>
            <th class="border border-neutral-700 p-2">Azione</th>
        </tr>

        <?php while ($u = $result->fetch_assoc()): ?>
        <tr class="bg-neutral-800">
            <td class="border border-neutral-700 p-2"><?= htmlspecialchars($u['name']) ?> <?= htmlspecialchars($u['surname']) ?></td>
            <td class="border border-neutral-700 p-2"><?= htmlspecialchars($u['email']) ?></td>
            <td class="border border-neutral-700 p-2"><?= htmlspecialchars($u['coupon_code']) ?></td>
            <td class="border border-neutral-700 p-2">
                <?= $u['coupon_used'] ? '✅ Usato' : '❌ Non usato' ?>
            </td>
            <td class="border border-neutral-700 p-2">
                <form method="post" action="check_coupon.php">
                    <input type="hidden" name="id" value="<?= $u['id'] ?>">
                    <input type="hidden" name="set_used" value="<?= $u['coupon_used'] ? 0 : 1 ?>">
                    <button class="bg-yellow-600 hover:bg-yellow-700 text-black px-3 py-1 rounded">
                        <?= $u['coupon_used'] ? 'Segna come non usato' : 'Segna come usato' ?>
                    </button>
                </form>
            </td>
        </tr>
        <?php endwhile; ?>
    </table>

    <a href="logout.php" class="bg-red-600 hover:bg-red-700 px-4 py-2 rounded text-black font-bold">Logout</a>

</body>
</html>
