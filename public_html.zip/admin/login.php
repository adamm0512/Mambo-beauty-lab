<?php
session_start();
require_once "config.php"; // connessione già corretta

// SE GIÀ LOGGATO → VAI ALLA DASHBOARD
if (isset($_SESSION['admin_id'])) {
    header("Location: dashboard.php");
    exit;
}

$error = false;

// GESTIONE LOGIN
if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    $username = trim($_POST['username'] ?? '');
    $password = $_POST['password'] ?? '';

    $stmt = $conn->prepare("SELECT id, password FROM admin WHERE username = ?");
    $stmt->bind_param("s", $username);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows === 1) {
        $admin = $result->fetch_assoc();

        // PASSWORD IN CHIARO
        if ($password === $admin['password']) {
            $_SESSION['admin_id'] = $admin['id'];
            $_SESSION['admin_username'] = $username;

            header("Location: dashboard.php");
            exit;
        }
    }

    $error = true;
}
?>

<!DOCTYPE html>
<html lang="it">
<head>
    <meta charset="UTF-8">
    <title>Admin Login | Mambo Beauty Lab</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-black min-h-screen flex items-center justify-center text-white">

    <form method="POST" class="bg-neutral-900 p-8 rounded-2xl w-80 shadow-xl border border-neutral-800">
        <h1 class="text-2xl font-bold mb-6 text-center text-yellow-500">
            Admin Login
        </h1>

        <input
            type="text"
            name="username"
            placeholder="Username"
            required
            class="w-full mb-4 p-2 rounded bg-black border border-neutral-700 focus:outline-none focus:border-yellow-500"
        >

        <div class="relative mb-6">
            <input
                type="password"
                id="password"
                name="password"
                placeholder="Password"
                required
                class="w-full p-2 rounded bg-black border border-neutral-700 focus:outline-none focus:border-yellow-500"
            >
            <button type="button" onclick="togglePassword()" class="absolute right-2 top-2 text-yellow-500">
                👁️
            </button>
        </div>

        <button
            type="submit"
            class="w-full bg-yellow-600 hover:bg-yellow-700 text-black font-bold py-2 rounded transition"
        >
            Entra
        </button>

        <?php if ($error): ?>
            <p class="text-red-500 text-center mt-4">
                Credenziali non valide
            </p>
        <?php endif; ?>
    </form>

    <script>
        function togglePassword() {
            const pwd = document.getElementById('password');
            if (pwd.type === 'password') {
                pwd.type = 'text';
            } else {
                pwd.type = 'password';
            }
        }
    </script>

</body>
</html>

