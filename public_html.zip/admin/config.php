<?php
$servername = "mysql.hostinger.com";
$username   = "u119628533_davideadduci";
$password   = "DavideAdduci1?";
$database   = "u119628533_Mambo";

$conn = new mysqli($servername, $username, $password, $database);

if ($conn->connect_error) {
    die("Connessione fallita: " . $conn->connect_error);
}
?>
