function openModal() {
    const modal = document.getElementById("modal");
    modal.classList.remove("hidden");
    modal.classList.add("flex");
}

function closeModal() {
    const modal = document.getElementById("modal");
    modal.classList.add("hidden");
    modal.classList.remove("flex");

    // reset per riapertura
    document.getElementById("registerForm").classList.remove("hidden");
    document.getElementById("successMessage").classList.add("hidden");
}

function togglePassword(inputId, button) {
    const input = document.getElementById(inputId);
    if (input.type === "password") {
        input.type = "text";
        button.textContent = "🙈";
    } else {
        input.type = "password";
        button.textContent = "👁";
    }
}

document.addEventListener("DOMContentLoaded", () => {
    const form = document.getElementById("registerForm");
    const successMessage = document.getElementById("successMessage");

    if (!form || !successMessage) return;

    form.addEventListener("submit", async (e) => {
        e.preventDefault();

        const formData = new FormData(form);

        try {
            const response = await fetch("/Mambo/register_php/register.php", {
                method: "POST",
                body: formData
            });

            const result = await response.json();

            if (result.success) {
                form.classList.add("hidden");
                successMessage.classList.remove("hidden");
            } else {
                alert("Registrazione fallita. Riprova.");
            }

        } catch (err) {
            alert("Errore di connessione. Riprova più tardi.");
        }
    });
});
