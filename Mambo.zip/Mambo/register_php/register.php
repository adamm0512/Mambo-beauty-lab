<?php
// register.php

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header('Location: index.html');
    exit;
}

// Recupero e pulizia dati
$nome     = trim($_POST['name'] ?? '');
$cognome  = trim($_POST['surname'] ?? '');
$email    = trim($_POST['email'] ?? '');
$telefono = trim($_POST['tel'] ?? '');
$date     = trim($_POST['birth_date'] ?? '');
$passwordInput = trim($_POST['password'] ?? '');
$consenso = isset($_POST['consenso']) && $_POST['consenso'] == '1' ? 1 : 0;

// Crittografia password
$hashedPassword = password_hash($passwordInput, PASSWORD_DEFAULT);

// Connessione al DB
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "mambo";

$conn = new mysqli($servername, $username, $password, $dbname);

// Controllo connessione
if ($conn->connect_error) {
    die("Connessione fallita: " . $conn->connect_error);
}

// Query per inserire i dati
$insertQuery = "INSERT INTO user (name, surname, email, password, birth_date, tel,consenso_privacy) VALUES ('$nome', '$cognome', '$email', '$hashedPassword', '$date', '$telefono','$consenso')";

if ($conn->query($insertQuery) === TRUE) {
    echo "<script>window.location.href = '../mambo.html';</script>";
} else {
    echo "<p class='message'>Errore durante la registrazione: " . $conn->error . "</p>";
}

$conn->close();
?>