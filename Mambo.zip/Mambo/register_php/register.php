<?php
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;
require 'PHPMailer/src/Exception.php';
require 'PHPMailer/src/PHPMailer.php';
require 'PHPMailer/src/SMTP.php';

// Includi i file di PHPMailer (adatta i percorsi se non usi composer)
require 'vendor/autoload.php'; 

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header('Location: ../mambo.html');
    exit;
}

// 1. Recupero dati (già presente nel tuo codice)
$nome     = trim($_POST['name'] ?? '');
$cognome  = trim($_POST['surname'] ?? '');
$email    = trim($_POST['email'] ?? '');
$telefono = trim($_POST['tel'] ?? '');
$date     = trim($_POST['birth_date'] ?? '');
$passwordInput = trim($_POST['password'] ?? '');
$consenso = isset($_POST['consenso']) && $_POST['consenso'] == '1' ? 1 : 0;

$hashedPassword = password_hash($passwordInput, PASSWORD_DEFAULT);

// 2. Generazione Codice Coupon Univoco
$coupon = "MAMBO-" . strtoupper(substr(md5(uniqid(rand(), true)), 0, 8));

// 3. Connessione al DB (Usa i prepared statements per la sicurezza!)
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "mambo";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    http_response_code(500);
    exit("Errore connessione");
}

// 4. Inserimento con Prepared Statement (Previene SQL Injection)
$stmt = $conn->prepare("INSERT INTO user (name, surname, email, password, birth_date, tel, consenso_privacy, coupon_code) VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
$stmt->bind_param("ssssssis", $nome, $cognome, $email, $hashedPassword, $date, $telefono, $consenso, $coupon);

if ($stmt->execute()) {
    // 5. Invio Email se l'inserimento è riuscito
    $mail = new PHPMailer(true);
    try {
        // Configurazione Server SMTP (Esempio Gmail)
        $mail->isSMTP();
        $mail->Host       = 'smtp.gmail.com'; 
        $mail->SMTPAuth   = true;
        $mail->Username   = 'mamboravarino@gmail.com'; // La tua mail
        $mail->Password   = 'TUA_APP_PASSWORD';        // Password specifica per app
        $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
        $mail->Port       = 587;

        // Destinatari
        $mail->setFrom('mamboravarino@gmail.com', 'Mambo Beauty Lab');
        $mail->addAddress($email, $nome);

        // Contenuto Email
        $mail->isHTML(true);
        $mail->Subject = 'Il tuo Coupon 50% - Mambo Beauty Lab';
        $mail->Body    = "
            <div style='font-family: Arial, sans-serif; text-align: center; background-color: #f4f4f4; padding: 20px;'>
                <h1 style='color: #D4AF37;'>Benvenuta in Mambo Beauty Lab, $nome!</h1>
                <p>Grazie per esserti preregistrata. Ecco il tuo regalo esclusivo per l'inaugurazione:</p>
                <div style='background: #000; color: #D4AF37; padding: 20px; font-size: 24px; font-weight: bold; border-radius: 10px; display: inline-block; margin: 20px 0;'>
                    $coupon
                </div>
                <p>Mostra questo codice alla cassa il giorno dell'inaugurazione per ricevere il <b>50% di sconto</b>.</p>
                <p>Ti aspettiamo in Via Roma 339/341, Ravarino!</p>
            </div>";

        $mail->send();
        echo "success"; // Risposta per lo script.js
    } catch (Exception $e) {
        // Log errore ma registrazione avvenuta
        echo "success"; 
    }
} else {
    http_response_code(500);
    echo "Errore DB";
}

$stmt->close();
$conn->close();
?>