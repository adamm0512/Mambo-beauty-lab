<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
require 'PHPMailer/src/Exception.php';
require 'PHPMailer/src/PHPMailer.php';
require 'PHPMailer/src/SMTP.php';


header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['success' => false]);
    exit;
}

/* ===== DATI ===== */
$nome     = trim($_POST['name'] ?? '');
$cognome  = trim($_POST['surname'] ?? '');
$email    = trim($_POST['email'] ?? '');
$telefono = trim($_POST['tel'] ?? '');
$dataNascita = $_POST['birth_date'] ?? '';
$password = $_POST['password'] ?? '';
$consenso = isset($_POST['consenso']) ? 1 : 0;

if (!$nome || !$email || !$password) {
    http_response_code(400);
    echo json_encode(['success' => false]);
    exit;
}

$hashedPassword = password_hash($password, PASSWORD_DEFAULT);
$coupon = 'MAMBO-' . strtoupper(bin2hex(random_bytes(4)));

/* ===== DB ===== */
$conn = new mysqli('localhost', 'root', '', 'mambo');

if ($conn->connect_error) {
    http_response_code(500);
    echo json_encode(['success' => false]);
    exit;
}

$stmt = $conn->prepare("
    INSERT INTO user 
    (name, surname, email, password, birth_date, tel, consenso_privacy, coupon_code)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?)
");

$stmt->bind_param(
    "ssssssis",
    $nome,
    $cognome,
    $email,
    $hashedPassword,
    $dataNascita,
    $telefono,
    $consenso,
    $coupon
);

if (!$stmt->execute()) {
    http_response_code(500);
    echo json_encode(['success' => false]);
    exit;
}

/* ===== MAIL ===== */
$mail = new PHPMailer\PHPMailer\PHPMailer(true);

try {
    $mail->isSMTP();
    $mail->Host = 'smtp.gmail.com';
    $mail->SMTPAuth = true;
    $mail->Username = 'mamboravarino@gmail.com';
    $mail->Password = 'rkma ijlz mlbq suyq';
    $mail->SMTPSecure = PHPMailer\PHPMailer\PHPMailer::ENCRYPTION_STARTTLS;
    $mail->Port = 587;

    $mail->setFrom('mamboravarino@gmail.com', 'Mambo Beauty Lab');
    $mail->addAddress($email, $nome);

    $mail->isHTML(true);
    $mail->Subject = 'Il tuo Coupon 50% - Mambo Beauty Lab';
    $mail->Body = "<h2>Ciao $nome</h2><p>Il tuo coupon: <b>$coupon</b></p>";

    $mail->send();

} catch (PHPMailer\PHPMailer\Exception $e) {
    // mail fallita, ma DB già salvato
}


/* ===== OK ===== */
echo json_encode(['success' => true]);

$stmt->close();
$conn->close();
?>