-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Creato il: Gen 15, 2026 alle 17:05
-- Versione del server: 10.4.32-MariaDB
-- Versione PHP: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `mambo`
--

-- --------------------------------------------------------

--
-- Struttura della tabella `user`
--

CREATE TABLE `user` (
  `id` int(11) NOT NULL,
  `name` varchar(200) NOT NULL,
  `surname` varchar(200) NOT NULL,
  `email` varchar(200) NOT NULL,
  `role` varchar(50) NOT NULL,
  `password` varchar(999) NOT NULL,
  `birth_date` date NOT NULL,
  `tel` varchar(40) NOT NULL,
  `consenso_privacy` tinyint(1) NOT NULL,
  `coupon_code` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dump dei dati per la tabella `user`
--

INSERT INTO `user` (`id`, `name`, `surname`, `email`, `role`, `password`, `birth_date`, `tel`, `consenso_privacy`, `coupon_code`) VALUES
(1, 'davide adduci ', 'adduci', 'davideaddu1234@gmail.com', '', '', '0000-00-00', '3318662310', 0, NULL),
(2, 'davide adduci ', 'adduci', 'davideaddu1234@gmail.com', '', '', '0000-00-00', '3318662310', 0, NULL),
(3, 'asdas ', 'asdds', 'aasddsa@asdasd.com', '', '', '0000-00-00', '1212212112', 0, NULL),
(4, 'as ', 'AS', 'aasddsa@asdasd.com', '', '', '0000-00-00', 'ASD', 0, NULL),
(5, 'davide', 'adduci', 'davideadduci1@gmail.com', '', '$2y$10$eg5ehK9osiKw0RSXkgRDBOIH.LMOpgqJQmpg9umLN0g5/53Y/v9l6', '2005-07-12', '3318662310', 0, NULL),
(6, 'davide', 'adduci', 'davideadduci1@gmail.com', '', '$2y$10$zKf/PsM/WJaTqe9B3scuUu1MxUVEPdUS02zO3BOp1YrzL26MEDQkG', '0000-00-00', '12122112', 0, NULL),
(7, 'asdasd', 'adduci', 'davideadduci1@gmail.com', '', '$2y$10$JLHi4AvDMPlLy3H888lqLepsOkxJn6RiNsx5etwrvic6rSfdrjRVO', '0012-12-12', '212121212112', 0, NULL),
(8, '12', '12', 'davideadduci1@gmail.com', '', '$2y$10$gJyuMLhA3qWjcw/BIetLSOE/6wZJcJh/JmM5cyHLo6.q/p9tkVopW', '1212-12-12', '1221', 1, NULL),
(9, 'davide', 'adduci', 'davideadduci1@gmail.com', '', '$2y$10$P0C9fmdOjMiqou3hZggriOyo20EzG07/CGN8LRdzAeSH7JVYHwS.y', '2005-07-12', '3318662310', 1, NULL),
(10, 'Adam', 'Shehab', 'adamshehab05@gmail.com', '', '$2y$10$exRyUjQJI0v3fopixOraVeSr4p8lYAOyBHX3DS6O2CbGptKpkxG6i', '2005-12-05', '3806537222', 1, NULL),
(11, 'Adam', 'Shehab', 'adamshehab05@gmail.com', '', '$2y$10$g8FeA6NpKfsNdRcy.bw83eWh/.F5PGMCZdBdl5.qa9A3.i75ZITHi', '2006-03-12', '3806537222', 1, NULL),
(12, 'Adam', 'Shehab', 'adamshehab05@gmail.com', '', '$2y$10$nOEYOyvfGTyLzqtzlfVg9OZMnvQg/wQdRaXbQJekL2nhNgL3EgO4C', '1999-03-12', '3806537222', 1, NULL),
(13, 'Rabab', 'Darwish', 'adamshehab05@gmail.com', '', '$2y$10$aAQHJNn158hY0L4QROYvb.spTtjv3RTvZlsBxzvOndFuQaWbNaZam', '2000-12-05', '3806537222', 1, NULL),
(14, 'Adam', 'Shehab', 'adamshehab05@gmail.com', '', '$2y$10$OxsRvafOeEqIVEjLifT.SeStT9tX/Ixbv3BsL/cjuO1Qwpa4MTn/e', '1999-03-12', '3806537222', 1, NULL),
(15, 'Adam', 'Shehab', 'adamshehab05@gmail.com', '', '$2y$10$p3ohlPVj.7qyFAwhrccxqeeAQ6K4.zBNF/.BIR3lzaU7LPDIUTMn2', '3222-02-12', '3806537222', 1, NULL);

--
-- Indici per le tabelle scaricate
--

--
-- Indici per le tabelle `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT per le tabelle scaricate
--

--
-- AUTO_INCREMENT per la tabella `user`
--
ALTER TABLE `user`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
